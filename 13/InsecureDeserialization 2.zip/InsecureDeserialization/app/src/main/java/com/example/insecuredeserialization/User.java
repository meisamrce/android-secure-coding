package com.example.insecuredeserialization;


import java.io.Serializable;

public class User implements Serializable {
    String username;
    String password;
    String role = "ROLE_AUTHOR";

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }


}
