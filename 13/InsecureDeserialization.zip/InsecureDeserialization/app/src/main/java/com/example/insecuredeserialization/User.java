package com.example.insecuredeserialization;

import android.util.Log;

import java.io.Serializable;

public class User implements Serializable {
    String username;
    String password;
    String role = "ROLE_AUTHOR";

    public User() {
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", role='" + role + '\'' +
                '}';
    }




}
