package com.example.insecuredeserialization;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 100;

    Button btnSave = null;
    Button btnLoad = null;
    EditText txtUsername = null;
    EditText txtPassword = null;
    String[] requiredPermissions = new String[] {
            Manifest.permission.WRITE_EXTERNAL_STORAGE
            , Manifest.permission.READ_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        for(int i = 0 ; i < requiredPermissions.length;i++)
        {
            if(ContextCompat.checkSelfPermission(MainActivity.this, requiredPermissions[i]) != PackageManager.PERMISSION_GRANTED)
            {
                reqPermissions();
            }
        }
        btnSave = (Button) findViewById(R.id.btnSave);
        btnLoad = (Button) findViewById(R.id.btnLoad);
        txtUsername = (EditText) findViewById(R.id.txtUsername);
        txtPassword = (EditText) findViewById(R.id.txtPassword);
        String path = Environment.getExternalStorageDirectory().toString() + "/Download/user2.dat";
        Log.e("App",path);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!txtUsername.getText().toString().isEmpty() && !txtPassword.getText().toString().isEmpty())
                {
                    User user = new User(txtUsername.getText().toString(), txtPassword.getText().toString());
                    try {
                        File file = new File(path);
                        FileOutputStream fos = new FileOutputStream(file);
                        ObjectOutputStream oos = new ObjectOutputStream(fos);
                        oos.writeObject(user);
                        oos.close();
                        fos.close();
                    } catch (Exception e) {
                        Log.d("App", e.getLocalizedMessage());
                    }
                    Toast.makeText(getApplicationContext(),"save success",Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"please fill all fields",Toast.LENGTH_SHORT).show();

                }
            }
        });

        btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (new File(path).exists()) {
                        File file = new File(path);
                        FileInputStream fis = new FileInputStream(file);
                        ObjectInputStream ois = new ObjectInputStream(fis);
                        User user = (User) ois.readObject();
                        ois.close();
                        fis.close();
                        if (!user.role.equals("ROLE_EDITOR")) {
                            Toast.makeText(getApplicationContext(),"Sorry, only editors have access!",Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(),"Success you are is editors!",Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(),"not found file!",Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.d("App", e.getLocalizedMessage());
                }

            }
        });


    }

    private void reqPermissions() {
        ActivityCompat.requestPermissions(MainActivity.this, requiredPermissions, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allPermissionsGranted = false;
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = true;
                } else {
                    allPermissionsGranted = false;
                    break;
                }
            }
        }
    }
}