package com.example.arbitrarycodeexecution;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Method;
import java.util.List;

import dalvik.system.DexClassLoader;

public class MainActivity extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 1337;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {

                if (shouldShowRequestPermissionRationale(
                        Manifest.permission.READ_EXTERNAL_STORAGE)) {
                }

                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);

                return;
            }
        }
        loadPlugins();
        loadUpdate();
    }

    private void loadPlugins(){
        try{
            List<PackageInfo> packs = getApplication().getPackageManager().getInstalledPackages(0);
            for (int i = 0; i < packs.size(); i++) {
                PackageInfo p = packs.get(i);
                String packageName = p.applicationInfo.packageName;
                if (packageName.startsWith("ir.example.app")) {
                    Context packageContext = createPackageContext(packageName,
                            CONTEXT_INCLUDE_CODE | CONTEXT_IGNORE_SECURITY);
                    Class<?> classLoader = packageContext.getClassLoader()
                            .loadClass("ir.example.app.plugin.Loader");
                    classLoader.getMethod("loadPlugin").invoke(null);
                }
            }

        }
        catch (Exception e){
            Log.e("App",e.toString());
        }
    }

    private void loadUpdate(){
        try{
            String path =  Environment.getExternalStorageDirectory().toString();
            File file = new File(path + "/meisam_app2.apk");
            Log.e("App",file.getAbsolutePath());

            if(file.exists() && file.isFile())
            {
                Log.e("App","apk is ok!");

                DexClassLoader dexClassLoader = new DexClassLoader(file.getAbsolutePath()
                        , getApplication().getCacheDir().getAbsolutePath(), null, ClassLoader.getSystemClassLoader().getParent());
                Class<?> version = dexClassLoader.loadClass("com.example.arbitrarycodeexecution.updater.VersionCheck");
                Log.e("App",version.getName());
                Object obj = (Object)version.newInstance();
                Method m = version.getMethod("getLatestVersion", null);
                m.invoke(obj);
            }
        }
        catch (Exception e){
            Log.e("App",e.toString());
        }
    }
}