package com.example.insecurecontentprovider2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn_access = (Button) findViewById(R.id.btn_access);
        btn_access.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText pinTxt = (EditText) findViewById(R.id.aci3notesPinText);
                String pin = "1234";
                String userpin = pinTxt.getText().toString();

                if (userpin.equals(pin)) {
                    ListView lview = (ListView) findViewById(R.id.aci3nlistView);
                    Cursor cr = getContentResolver().query(NotesProvider.CONTENT_URI, new String[] {"_id", "title", "note"}, null, null, null);
                    String[] columns = {NotesProvider.C_TITLE, NotesProvider.C_NOTE};
                    int [] fields = {R.id.title_entry, R.id.note_entry};
                    SimpleCursorAdapter adapter = new SimpleCursorAdapter(getApplicationContext(), R.layout.notes_entry ,cr, columns, fields, 0);
                    lview.setAdapter(adapter);

                }
                else {
                    Toast.makeText(getApplicationContext(), "Please Enter a valid pin!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}