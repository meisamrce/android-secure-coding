package com.example.intentinjection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    Button btnLogin = null;
    Button btnExit = null;
    EditText txtUsername = null;
    EditText txtPassword = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnExit = (Button) findViewById(R.id.btnExit);
        txtUsername = (EditText) findViewById(R.id.txtUsername);
        txtPassword = (EditText) findViewById(R.id.txtPassword);

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(txtUsername.getText().toString().equals("admin") && txtPassword.getText().toString().equals("123"))
               {
                   Intent i = new Intent(MainActivity.this,Dashboard.class);
                   i.putExtra("username",txtUsername.getText().toString());
                   startActivity(i);
               }
               else
               {
                   Toast.makeText(getApplicationContext(),"Username or Password incorrect!",Toast.LENGTH_SHORT).show();
               }
            }
        });


    }
}