package com.example.weakcryptography;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    Button btnLogin = null;
    Button btnExit = null;
    EditText txtUsername = null;
    EditText txtPassword = null;
    public static final MediaType JSON
            = MediaType.get("application/json; charset=utf-8");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnExit = (Button) findViewById(R.id.btnExit);
        txtUsername = (EditText) findViewById(R.id.txtUsername);
        txtPassword = (EditText) findViewById(R.id.txtPassword);

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    OkHttpClient client = new OkHttpClient();
                    JSONObject data = new JSONObject();
                    data.put("username",encrypt(txtUsername.getText().toString()));
                    data.put("password",encrypt(txtPassword.getText().toString()));
                    RequestBody body = RequestBody.create(data.toString(), JSON);
                    Request request = new Request.Builder()
                            .url("http://138.68.182.36:999/login")
                            .post(body)
                            .build();
                    Response response = client.newCall(request).execute();
                    Toast.makeText(getApplicationContext(),"ok!",Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Log.e("APP",e.toString());
                }
            }
        });


    }


    private String encrypt(String value) {
        try {
            String key = getResources().getString(R.string.key);
            SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
            byte[] encrypted = cipher.doFinal(value.getBytes());
            String t =  new String(encrypted);
            byte[] data = t.getBytes("UTF-8");
            return Base64.encodeToString(data, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}