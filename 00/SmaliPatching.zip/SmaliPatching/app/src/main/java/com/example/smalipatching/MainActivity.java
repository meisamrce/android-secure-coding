package com.example.smalipatching;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnEdm = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnEdm = (Button) findViewById(R.id.btnEdm);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        btnEdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeveloperMode developerMode = new DeveloperMode();
                if(developerMode.getStatus())
                {
                    Toast.makeText(getApplicationContext(),"you are Developer :)",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"you are not Developer :(",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}