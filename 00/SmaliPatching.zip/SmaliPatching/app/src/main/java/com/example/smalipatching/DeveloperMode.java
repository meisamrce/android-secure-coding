package com.example.smalipatching;

import android.util.Log;
import android.widget.Toast;

import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DeveloperMode {

    public static final MediaType JSON
            = MediaType.get("application/json; charset=utf-8");

    public boolean getStatus(){
        try{
            OkHttpClient client = new OkHttpClient();
            JSONObject data = new JSONObject();
            RequestBody body = RequestBody.create(data.toString(), JSON);
            Request request = new Request.Builder()
                    .url("http://138.68.182.36:999/checkDeveloperMode")
                    .post(body)
                    .build();
            Response response = client.newCall(request).execute();
            if(response.body().string().equals("OK"))
                return true;
            else
                return false;
        }catch (Exception e){
            Log.e("APP",e.toString());
            return false;
        }

    }
}
