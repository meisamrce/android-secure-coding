package com.example.ndk1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'ndk1' library on application startup.
    static {
        System.loadLibrary("ndk1");
    }

    public native String stringFromJNI();
    public native boolean checkLic(String str);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.mybtn);
        EditText EditText = findViewById(R.id.text);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String k = EditText.getText().toString();
                if(checkLic(k))
                {
                    Toast.makeText(getApplicationContext(),"Correct Key",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Invalid Key",Toast.LENGTH_SHORT).show();
                }
            }

        });

        // Example of a call to a native method
    }

    /**
     * A native method that is implemented by the 'ndk1' native library,
     * which is packaged with this application.
     */
}