#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_ndk1_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}


extern "C" JNIEXPORT bool JNICALL
Java_com_example_ndk1_MainActivity_checkLic(
        JNIEnv* env,jobject,jstring key) {
const char *key2 = env->GetStringUTFChars(key, 0);
if(strcmp(key2,"salam123") == 0)
    return true;
else
    return false;
}