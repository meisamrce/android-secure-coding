package com.example.insecurelogging;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.Objects;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    Button btnLogin = null;
    Button btnExit = null;
    EditText txtUsername = null;
    EditText txtPassword = null;
    public static final MediaType JSON
            = MediaType.get("application/json; charset=utf-8");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnExit = (Button) findViewById(R.id.btnExit);
        txtUsername = (EditText) findViewById(R.id.txtUsername);
        txtPassword = (EditText) findViewById(R.id.txtPassword);

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    OkHttpClient client = new OkHttpClient();
                    JSONObject data = new JSONObject();
                    data.put("username",txtUsername.getText().toString());
                    data.put("password",txtPassword.getText().toString());
                    RequestBody body = RequestBody.create(data.toString(), JSON);
                    Request request = new Request.Builder()
                            .url("http://138.68.182.36:999/login")
                            .post(body)
                            .build();
                    Response response = client.newCall(request).execute();
                    Log.e("APP",response.body().string());
                    Toast.makeText(getApplicationContext(),"ok!",Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Log.e("APP",e.toString());
                }
            }
        });


    }
}