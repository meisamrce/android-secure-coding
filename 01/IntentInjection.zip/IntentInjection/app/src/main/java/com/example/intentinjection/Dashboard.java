package com.example.intentinjection;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Dashboard extends AppCompatActivity {


    TextView txt_username = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        txt_username = (TextView) findViewById(R.id.txt_username);
        String username = getIntent().getStringExtra("username");
        txt_username.setText("Hi " + username );
    }
}