package com.example.insecurebroadcastreceiver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 100;

    String[] requiredPermissions = new String[] {
            Manifest.permission.SEND_SMS

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        for(int i = 0 ; i < requiredPermissions.length;i++)
        {
            if(ContextCompat.checkSelfPermission(MainActivity.this, requiredPermissions[i]) != PackageManager.PERMISSION_GRANTED)
            {
                reqPermissions();
            }
        }
    }

    private void reqPermissions() {
        ActivityCompat.requestPermissions(MainActivity.this, requiredPermissions, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allPermissionsGranted = false;
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = true;
                } else {
                    allPermissionsGranted = false;
                    break;
                }
            }
        }
    }

}