package com.example.sslpinning;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import okhttp3.CertificatePinner;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public class MainActivity extends AppCompatActivity {



    Button btnSend = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy gfgPolicy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(gfgPolicy);

        btnSend = (Button) findViewById(R.id.btnSend);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    String hostname = "pririb.ir";
                    CertificatePinner certificatePinner = new CertificatePinner.Builder()
                            .add(hostname, "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
                            .build();
                    OkHttpClient client = new OkHttpClient.Builder()
                            .certificatePinner(certificatePinner)
                            .build();

                    Request request = new Request.Builder()
                            .url("https://" + hostname)
                            .build();
                    client.newCall(request).execute();
                    Log.e("App","OK!");
                    Toast.makeText(getApplicationContext(),"Success Request!",Toast.LENGTH_SHORT).show();
                }
                catch (Exception e){
                    //Log.e("App",e.toString());
                    Toast.makeText(getApplicationContext(),"Error Request",Toast.LENGTH_SHORT).show();
                }
            }
        });



    }



}