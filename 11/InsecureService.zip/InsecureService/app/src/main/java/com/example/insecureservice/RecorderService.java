package com.example.insecureservice;

import android.app.Service;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class RecorderService extends Service implements MediaRecorder.OnInfoListener {
    private MediaRecorder mediaRecorder;
    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        try{
            startRecording();
        }
        catch (Exception e){
            Log.e("App",e.toString());
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    private void startRecording() {
        Log.e("App","startRecording ....");
        Toast.makeText(this, "Audio recording started!", Toast.LENGTH_SHORT).show();
        try {
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            File outputFile = getOutputFile();
            mediaRecorder.setOutputFile(outputFile.getAbsolutePath());
            mediaRecorder.prepare();
            mediaRecorder.start();
            new Timer().schedule(new TimerTask() {
                @Override
                public void run() {
                    stopRecording();
                }
            },5000);
        } catch (Exception e) {
            Log.d("App", "Exception: " + e.getMessage());
        }
    }

    private void stopRecording() {
        try {
            Log.e("App","stopRecording ....");
            if (null != mediaRecorder) {
                mediaRecorder.stop();
                mediaRecorder.reset();
                mediaRecorder.release();
                mediaRecorder = null;
            }
            stopSelf();
        } catch (Exception e) {
            Log.d("App", "Exception: " + e.getMessage());
        }
        Toast.makeText(getApplicationContext(), "Audio recording stopped!", Toast.LENGTH_SHORT).show();
    }

    private File getOutputFile() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmssSSS", Locale.US);
        String fullPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                .getAbsolutePath()
                + "/rec_"
                + dateFormat.format(new Date())
                + ".mp3";
        Toast.makeText(getApplicationContext(), "File: " + fullPath, Toast.LENGTH_SHORT).show();
        return new File(fullPath);
    }

    @Override
    public void onInfo(MediaRecorder mr, int what, int extra) {
        stopRecording();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopRecording();
    }
}
