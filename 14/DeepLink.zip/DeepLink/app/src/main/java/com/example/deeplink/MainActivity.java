package com.example.deeplink;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        String action = intent.getAction();
        Uri data = intent.getData();

        Log.d("App", "ok!");
        Log.d("App", "Action: " + action + " Data: " + data);

        try {
            if (data.getQueryParameter("key").equals(getString(R.string.key))) {
                findViewById(R.id.container).setVisibility(View.VISIBLE);
                Log.d("App","Success Key" );
                Toast.makeText(getApplicationContext(),"Success Key!",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(),"Wrong key!",Toast.LENGTH_SHORT).show();
                Log.d("App","Wrong Key" );
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),"No key!",Toast.LENGTH_SHORT).show();
            Log.d("App","No Key" );
            Log.e("App", e.getMessage());
        }
    }
}